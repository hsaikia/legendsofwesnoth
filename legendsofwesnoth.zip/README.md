legendsofwesnoth
================

Trueskill based ladder for the open source strategy game 'Battle for Wesnoth'. Uses PHP powered by CodeIgnitor framework and MySql.
