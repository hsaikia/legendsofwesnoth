<div>
Some general guidelines to follow.
</div>
