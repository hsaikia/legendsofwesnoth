<div id="logo">
	<a href="<?php echo site_url('main') ?>">
		<img src="<?php echo base_url(); ?>assets/images/logolad.png" width="500" alt="Home"/>
	</a>
</div>
