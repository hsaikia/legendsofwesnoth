<?php $this->load->view('title.php'); ?> 
<body>
	<center>
<div id="main">
<div id="header">
<?php $this->load->view('logo.php'); ?> 
</div>
<div class="content">Congratulations! You have successfully registered at Legends of Wesnoth! 
Click <a href="<?php echo site_url('main'); ?>">here</a> to login!</div>
</div>
	</center>
</body>
<?php $this->load->view('footer.php'); ?> 

