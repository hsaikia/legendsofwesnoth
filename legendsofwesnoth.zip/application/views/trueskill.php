<div>
Welcome to Legends of Wesnoth! The ladder which rates your BfW games according to the Trueskill rating system. The hallmarks of this ladder are :
<ul>
	<li>User friendly interface and navigation.</li>
	<li>Trueskill rating system.</li>
	<li>Dedicated page for every game.</li>
	<li>Improved player profiles.</li>
	<li>Career graph and faction stats.</li>
	<li>Possibility to rate 2v2 games. (Upcoming)</li>
</ul>
</div>
