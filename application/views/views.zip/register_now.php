<div id="register_message" class = "content">
<h2><a href="<?php echo site_url('user_session/register'); ?>"><u>Register</u></a> Now!</h2>
</div>
