<div id="footer">
	This ladder is not associated in any way with the offical Wesnoth forum or its moderators/developers. <br><br>
<a href=#>Terms of Use</a> |
<a href=#>Privacy Policy</a> |
<a href=#>Contact</a>
</div>
<br>

